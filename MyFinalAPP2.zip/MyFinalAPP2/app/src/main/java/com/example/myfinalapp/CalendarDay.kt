package com.example.myfinalapp

data class CalendarDay(    val day: Int,
                           val month: Int,
                           val year: Int
) {
    val dateString: String
        get() = "$year-${String.format("%02d", month + 1)}-${String.format("%02d", day)}"
}
