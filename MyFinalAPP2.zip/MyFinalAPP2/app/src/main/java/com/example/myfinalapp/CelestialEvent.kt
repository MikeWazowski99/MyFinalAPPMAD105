package com.example.myfinalapp

data class CelestialEvent(
    val CelestialName: String,
    val date: String,
    val time: String,
)

