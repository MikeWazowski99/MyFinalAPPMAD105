package com.example.myfinalapp

import android.app.AlertDialog
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat

import java.util.*

class MainActivity5 : AppCompatActivity() {
    private lateinit var calendarAdapter: CelestialEventAdapter
    private val celestialEvents = mutableListOf<CelestialEvent>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)

        val gridView = findViewById<GridView>(R.id.gridView)

        val calendar = generateCalendar()
        calendarAdapter = CelestialEventAdapter(this, calendar, celestialEvents) { date ->
            showAddEventDialog(date)
        }

        gridView.adapter = calendarAdapter
    }





    private fun showAddEventDialog(date: String) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_event, null)

        val eventNameEditText = dialogView.findViewById<EditText>(R.id.eventNameEditText)
        val eventDetailsEditText = dialogView.findViewById<EditText>(R.id.eventDetailsEditText)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Celestial Event")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val eventName = eventNameEditText.text.toString()
                val eventDetails = eventDetailsEditText.text.toString()

                val newEvent = CelestialEvent(date, eventName, eventDetails)
                celestialEvents.add(newEvent)  // Now it should work
                calendarAdapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    // Function to generate a list of CalendarDay objects for the month
    private fun generateCalendar(): List<CalendarDay> {
        val calendar = Calendar.getInstance()
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        val daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)
        val calendarDays = mutableListOf<CalendarDay>()

        for (day in 1..daysInMonth) {
            calendarDays.add(CalendarDay(day, currentMonth, currentYear))
        }

        return calendarDays
    }
}
