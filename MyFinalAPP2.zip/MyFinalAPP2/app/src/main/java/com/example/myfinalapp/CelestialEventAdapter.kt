package com.example.myfinalapp

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat

class CelestialEventAdapter(        private val context: Context,
                                    private val calendar: List<CalendarDay>,
                                    private val celestialEvents: List<CelestialEvent>,
                                    private val onDateClickListener: (String) -> Unit
) : BaseAdapter() {

    override fun getCount(): Int = calendar.size

    override fun getItem(position: Int): Any = calendar[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val day = getItem(position) as CalendarDay
        val celestialEvent = celestialEvents.find { it.date == day.dateString }

        val textView = TextView(context)
        textView.text = day.day.toString()
        textView.setBackgroundResource(R.drawable.calendar_cell_background)  // Customize the background
        textView.setOnClickListener {
            onDateClickListener.invoke(day.dateString)
        }

        if (celestialEvent != null) {
            // Display a marker or indicator for events on this date
            textView.setTextColor(ContextCompat.getColor(context, R.color.eventMarkerColor))
        }

        // Customize the appearance of each cell as needed

        return textView
    }
}